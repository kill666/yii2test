<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'User Transaction';
$this->params['breadcrumbs'] = false;
$this->params['breadcrumbs'][] = $this->title;
$s = \yii\helpers\ArrayHelper::map($status, 'id', 'name');
?>
<div class="site-index">
	Cумма долга:<?= Html::encode($price) ?>
	<table class="table">
		<thead><tr>
				<td>дата</td>
				<td>Дебет\кредит</td>
				<td>Статус</td>
				<td>Комментарий</td>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($list_transaction as $key => $value) { ?>
				<tr>
					<td><?= $value['created_at'] ?></td>
					<td><?= $value['money'] ?></td>
					<td><?= $s[$value['status_id']] ?></td>
					<td><?= $value['comment'] ?></td>
				</tr>
			<?php } ?>
		</tbody>

	</table>
	<?php // print_r($status) ?>
	<?= Html::a('Отчитаться', Url::toRoute('user/report'), ['class' => 'col-sm-3']) ?>
</div>
