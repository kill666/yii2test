<?php
/* @var $this yii\web\View */

namespace app\models;

//use yii\bootstrap\Html;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

$this->title = 'Admin';
$this->params['breadcrumbs'] = array('Admin');
?>
<div class="site-index">
	<span class="col-lg-12">В кассе: <?= $price ?></span>
	<table class="table">
		<thead><tr>
				<td>Пользователя номер</td>
				<td>дата</td>
				<td>Дебет\кредит</td>
				<td>Статус</td>
				<td>Комментарий</td>
				<td>Управление</td>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($list_transaction as $key => $value) { ?>
				<tr>
					<td><?= $value['user_id'] ?></td>
					<td><?= $value['created_at'] ?></td>
					<td><?= $value['money'] ?></td>
					<td><?= $status[$value['status_id']] ?></td>
					<td><?= $value['comment'] ?></td>
					<td>
						<?php
						$form = ActiveForm::begin([
									'id' => 'admin-spent',
									'action' => Url::to(['admin/outcoming']),
									'options' => ['class' => 'form-horizontal'],
									'fieldConfig' => [
										'template' => "{label}\n<div class=\"col-lg-3\">{input}</div>\n<div class=\"col-lg-8\">{error}</div>",
										'labelOptions' => ['class' => 'col-lg-1 control-label'],
									],
						]);
						?>
						<select name="company_id"><?php
							foreach ($company as $value2) {
								echo '<option value="' . $value2['id'] . '">' . $value2['name'] . '</option>';
							}
							?>
						</select>
						<input type="hidden" name="id" value="<?= $value['id'] ?>" />
						<?= Html::submitButton('Отправить', ['class' => 'btn btn-primary']) ?>
						<?php ActiveForm::end(); ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
	<?= Html::a('Пользователи', Url::toRoute('admin/users'), ['class' => 'col-sm-3']) ?>
	<?= Html::a('Операция', Url::toRoute('admin/spent'), ['class' => 'col-sm-3']) ?>
	<?php //Html::a('Настройка', Url::toRoute('admin/options'), ['class' => 'col-sm-3'])  ?>
</div>
