<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Options */
/* @var $form ActiveForm */
$this->params['breadcrumbs'][] = ['label' => 'Отправление'];
?>
<div class="Option">
	Отправлено!
	<?php
//	foreach ($model->attributes as $key => $value) {
//		echo $key . ' : ' . $value . ' ';
//	}
	?>

</div><!-- Option -->
