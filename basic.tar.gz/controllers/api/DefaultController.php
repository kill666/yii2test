<?php

namespace app\controllers\api;

use Yii;
use yii\web\Controller;
use app\models\Transaction;
use app\models\LoginForm;
use app\models\User;
use app\models\Kassa;
use app\models\Company;

class DefaultController extends Controller {

	public function actionIndex() {
		return $this->render('index');
	}

// Деньги возвращенные пользователем в кассу
	public static function save(Transaction $model) {
		$kassa = Kassa::findOne(1);
		$user = User::findOne($model->user_id);
		$kassa->money = $kassa->money + $model->money;
		$user->money = $user->money - $model->money;
		$transaction = Yii::$app->db->beginTransaction();
		if ($kassa->save() && $user->save()) {
			$transaction->commit();
			return true;
		} else {
			$transaction->rollBack();
		}
		return FALSE;
	}

	public static function send(Transaction $model) {
//		$company = Company::findOne(1);
//		$company->money += 1;
//		$company->save();
		return true;
	}

}
