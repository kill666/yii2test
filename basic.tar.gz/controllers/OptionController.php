<?php

namespace app\controllers;

class OptionController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
