<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Transaction;
use app\models\User;
use app\models\Status;

class UserController extends Controller {

	public $status_id = 4;

	public function beforeAction($action) {
		if (!Yii::$app->user->isGuest) {
//			$this->id = Yii::$app->user->identity->id;
			return parent::beforeAction($action);
		}
		$this->layout = 'error/permission';
		return TRUE;
	}

	public function actionIndex() {
		return $this->actionTransaction();
	}

	public function actionTransaction() {

		$id = Yii::$app->user->getId();

		$model = new Transaction();
		$status = \app\models\Status::find()->asArray()->all();
		$list_transaction = Transaction::find()->where(['user_id' => $id])->all();
		$user = User::findOne($id);
		$result = $this->render('//user/transactions', [
			'list_transaction' => $list_transaction,
			'price' => $user->money,
			'status' => $status,
			'model' => $model]);
		return $result;
	}

	public function actionReport() {
		$trans = new Transaction();
		$result = $this->render('//user/report', ['model' => $trans]);
		return $result;
	}

	public function actionSave() {
		$post = Yii::$app->request->post();
		$model = new Transaction();
		$model->load($post);
		$model->user_id = \Yii::$app->user->getId();
		$model->status_id = $this->status_id;
		if ($model->validate()) {
			$status = Status::findOne($this->status_id);
			$class = 'app\controllers\report\\' . $status->class . 'Controller';
			$result = false;
			if (class_exists($class) && method_exists($class, 'save')) {
				$result = $class::save($model);
			}
			if ($result && $model->save()) {
				return $this->render('/save', ['model' => $model]);
			}
		}

		if (!$model->hasErrors()) {
			$result = $this->render('/save', ['model' => $model]);
		} else {
			$result = $this->render('//user/report', ['model' => $model, 'errors' => $model->getErrors()]);
		}
//		} else {
		return $result;
	}

}
