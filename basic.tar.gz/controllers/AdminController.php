<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\Transaction;
use app\models\LoginForm;
use app\models\User;
use app\models\Status;
use app\models\Company;
use app\models\Kassa;

/**
 *
 *
 */
class AdminController extends Controller {

	public function actions() {
		return [
			'error' => [
				'class' => 'yii\web\ErrorAction',
			]
		];
	}

	public function beforeAction($action) {
		$model = new LoginForm();
		$model->load(Yii::$app->request->post());
		$model->login();
		if (!Yii::$app->user->isGuest) {
			$id = Yii::$app->user->getId();
			if ($id != 100) {
				$this->layout = 'error/permission';
			} else {
				return parent::beforeAction($action);
			}
		}
		$this->layout = 'error/permission';
		return TRUE;
	}

	public function actionIndex() {

//		$list_transaction[] = [];
//		$model = new Transaction();
//		$list_transaction = Transaction::find()->all();
//		$result = $this->render('//admin/transactions', [
//			'list_transaction' => $list_transaction,
//			'model' => $model
//		]);
		return $this->actionTransaction();
//		return $result;
//		return $this->render('//admin/transactions');
	}

	public function actionSpent() { // Операции по кассе
		$model = new Transaction();
		$users = User::find()->asArray()->all();
		$status = Status::find()->asArray()->all();
		$class = 'app\controllers\Controller';
		return $this->render('//admin/spent', [
					'model' => $model,
					'users' => $users,
					'status' => $status
		]);
	}

	public function actionSave() { // Сохранение операций по кассе
		$model = new Transaction();
		$post = Yii::$app->request->post();
		if ($model->load($post) && $model->validate()) {
			$status = Status::findOne($model->status_id);
			$class = 'app\controllers\report\\' . $status->class . 'Controller';
			$result = false;
			if (class_exists($class) && method_exists($class, 'save')) {
				$result = $class::save($model);
//				$result = $rez->save($model);
			}
			if ($result && $model->save()) {
				return $this->render('/save', ['model' => $model]);
			}
		}
		$users = User::find()->asArray()->all();
		$status = Status::find()->all();
		return $this->render('//admin/spent', [
					'model' => $model,
					'users' => $users,
					'status' => $status,
					'errors' => $model->hasErrors()
		]);
//		} else {
	}

	public function actionIncoming() {// Входящие сообщения от внешних систем
		Yii::$app->response->format = Response::FORMAT_JSON;
		$model = new Transaction();
		$post = Yii::$app->request->post();
		if ($model->load($post) && $model->validate()) {
			$company = Company::findOne($model->user_id);
			$api = $company->api;
			$result = false;
			$class = new $api($this->id, $this->module);
			if (class_exists($class) && method_exists($class, 'save')) {
				$result = $class::save($model);
			}
			if ($result && $model->save()) {
				return json_encode(['response' => TRUE]);
			}
		}
		return json_encode(['response' => FALSE, 'errors' => $model->hasErrors()]);
	}

	public function actionOutcoming() {// Исходящие сообщения ко внешним системам
//		Yii::$app->response->format = Response::FORMAT_JSON;
		$id = Yii::$app->request->post('id');
		$company_id = Yii::$app->request->post('company_id');
//		$model = new Transaction();
		$models = Transaction::findOne($id);
		$company = Company::findOne($company_id);
		$class = (string) $company['api'];
		$result = false;
		if (class_exists($class) && method_exists($class, 'send')) {
			$result = $class::send($models);
		}
		if ($result) {
			$result = $this->render('/send', ['model' => $models]);
		} else {
			$result = $this->actionTransaction();
		}
		return $result;
//		return $this->actionTransaction();
//		return json_encode(['response' => FALSE, 'errors' => $model->hasErrors()]);
	}

	public function actionTransaction() {
		$list_transaction[] = [];
		$model = new Transaction();
		$status = Status::find()->asArray()->all();
		foreach ($status as $value) {
			$status[$value['id']] = $value['name'];
		}
		$kassa = Kassa::findOne(1);
		$list_transaction = Transaction::find()->all();
		$company = Company::find()->all();
		$result = $this->render('//admin/transactions', [
			'list_transaction' => $list_transaction,
			'price' => $kassa->money,
			'status' => $status,
			'company' => $company,
			'model' => $model
		]);
		return $result;
	}

	public function actionOptions() {
		return $this->render('//admin/options');
	}

	public function actionUsers() {
		$users = User::find()->all();
		return $this->render('//admin/users', ['users' => $users]);
	}

}
