<?php

namespace app\controllers\report;

use Yii;
use yii\web\Controller;
use app\models\Transaction;
use app\models\LoginForm;
use app\models\User;
use app\models\Kassa;

class CashbackController extends \yii\web\Controller {

	public function actionIndex() {
		return $this->render('index');
	}

// Деньги возвращенные пользователем в кассу
	public static function save($model) {
		$kassa = Kassa::findOne(1);
		$user = User::findOne($model->user_id);
		$kassa->money += $model->money;
		$user->money = $user->money - $model->money;
		$transaction = Yii::$app->db->beginTransaction();
		if ($kassa->save() && $user->save()) {
			$transaction->commit();
			return true;
		} else {
			$transaction->rollBack();
		}
		return FALSE;
	}

}
