<?php

namespace app\controllers\report;

use Yii;
use yii\web\Controller;
use app\models\Transaction;
use app\models\LoginForm;
use app\models\User;
use app\models\Kassa;

class SpentController extends \yii\web\Controller {

	public function actionIndex() {
		return $this->render('index');
	}

// Просто раход денег из кассы
	public static function save($model) {
		$kassa = Kassa::findOne(1);
		$kassa->money = $kassa->money - $model->money;
		if ($kassa->save()) {
			return true;
		}
		return FALSE;
	}

}
